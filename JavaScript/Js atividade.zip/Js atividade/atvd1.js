// exercicio 1
let nome = "Victor De castro barroso"
newName = nome.split(" ")
console.log(newName);
let firstName = newName[0]
let secondName = newName[1]
console.log(`Seu nome é ${newName[0].toLocaleUpperCase()}, ja seu sobrenome é ${newName[1].toLocaleUpperCase()}, correto?`)
console.log(nome.substring(0,6));
